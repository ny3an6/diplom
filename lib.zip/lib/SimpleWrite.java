import gnu.io.*;

import java.io.*;
import java.util.*;

public class SimpleWrite implements Runnable, SerialPortEventListener {

    public void run() {
    }
    static Enumeration portList;
    static CommPortIdentifier portId;
    static String messageString = "AAA";
    static char ch = '"';
    static String dest = ch + "01739557775" + ch;  // 11 Digit Mobile Number.
    static InputStream inputStream;
    static SerialPort serialPort;
    static OutputStream outputStream;

    public void serialEvent(SerialPortEvent event) {
        switch (event.getEventType()) {
            case SerialPortEvent.BI:
            case SerialPortEvent.OE:
            case SerialPortEvent.FE:
            case SerialPortEvent.PE:
            case SerialPortEvent.CD:
            case SerialPortEvent.CTS:
            case SerialPortEvent.DSR:
            case SerialPortEvent.RI:
            case SerialPortEvent.OUTPUT_BUFFER_EMPTY:
                break;
            case SerialPortEvent.DATA_AVAILABLE: {

                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                String line = "";
                try {

                    while ((line = reader.readLine()) != null) {
                        System.out.println(line);
                    }
                } catch (IOException e) {
                    System.err.println("Error while reading Port " + e);
                }
                break;

            }
        } //switch
    }

    public SimpleWrite(SerialPort serial) {
        try {
            inputStream = serial.getInputStream();
            try {
                serial.addEventListener(this);
            } catch (TooManyListenersException e) {
                System.out.println("Exception in Adding Listener" + e);
            }
            serial.notifyOnDataAvailable(true);

        } catch (Exception ex) {
            System.out.println("Exception in getting InputStream" + ex);
        }

    }

    public static void main(String[] args) {
        System.out.println(RXTXVersion.getVersion());
        System.out.println(RXTXVersion.nativeGetVersion());

        String line1 = "AT+CSMS=1\r\n";
        String line2 = "AT+CMGS=" + dest + "\r\n";
        String line3 = messageString + "\r\n";

        portList = CommPortIdentifier.getPortIdentifiers();
        System.out.println(portList.hasMoreElements());
        //System.out.println(portList.nextElement());

        while (portList.hasMoreElements()) {
            portId = (CommPortIdentifier) portList.nextElement();
            System.out.println("Port type: " + portId.getPortType());
            System.out.println("Port name: " + portId.getName());
            if (portId.getPortType() == CommPortIdentifier.PORT_SERIAL) {
                System.out.println("Port name: " + portId.getName());
                if (portId.getName().equals("/dev/ttyS0")) {
                    System.out.println("SMS Sending....Port Found");
                    try {
                        serialPort = (SerialPort) portId.open("SimpleWriteApp", 2000);
                        SimpleWrite wr = new SimpleWrite(serialPort);

                    } catch (PortInUseException e) {
                        System.out.println("Port In Use " + e);
                    }
                    try {
                        outputStream = serialPort.getOutputStream();
                    } catch (IOException e) {
                        System.out.println("Error writing to output stream " + e);
                    }
                    try {
                        serialPort.setSerialPortParams(9600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
                    } catch (UnsupportedCommOperationException e) {
                        System.out.println("Unsupported " + e);
                    }
                    try {
                        outputStream.write(line1.getBytes());
                        outputStream.write(line1.getBytes());
                        outputStream.write(line2.getBytes());
                        outputStream.write(line3.getBytes());
                        outputStream.write(26);
                        outputStream.flush();
                    } catch (Exception e) {
                        System.out.println("Error writing message " + e);
                    }
                }
            }
        }
    }

    /**
     * show text in the text window
     *
     * @param Text text string to show on the display
     */
    public static void showText(String Text) {
        System.out.println(Text);
    }
}
