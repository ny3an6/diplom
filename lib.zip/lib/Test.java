import gnu.io.*;

import java.io.*;
import java.util.*;

public class Test {

    public static void main(String[] args) {
        System.out.println(RXTXVersion.getVersion());
        System.out.println(RXTXVersion.nativeGetVersion());
   }

}
